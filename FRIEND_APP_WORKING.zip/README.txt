Open index.html in a browser. Upload index.html and the assets folder together to GitHub Pages. Do not rename the assets folder.
